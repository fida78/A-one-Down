import type { Metadata } from "next";
import LegalPage, { LegalSection } from "@/components/LegalPage";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Disclaimer",
  description: `Disclaimer regarding the use of ${siteConfig.name} and third-party content.`,
};

export default function DisclaimerPage() {
  return (
    <LegalPage title="Disclaimer" updated="January 1, 2026">
      <p>
        Please read this Disclaimer carefully before using {siteConfig.name}. By using the App,
        you acknowledge and agree to the terms described below.
      </p>

      <LegalSection title="No Ownership or Hosting of Third-Party Content">
        <p>
          {siteConfig.name} does not own, host, or store any third-party video content. The App
          functions as a tool that allows users to retrieve publicly available videos from
          supported platforms based on a link the user provides.
        </p>
      </LegalSection>

      <LegalSection title="User Responsibility">
        <p>
          Users are solely responsible for ensuring they have the necessary permission or legal
          right to download and use any content accessed through the App. This includes complying
          with copyright law and the terms of service of the platform hosting the original
          content.
        </p>
      </LegalSection>

      <LegalSection title='"As Is" Basis'>
        <p>
          The App is provided on an "as is" and "as available" basis, without warranties of any
          kind, whether express or implied. We do not guarantee that the App will be error-free,
          uninterrupted, or compatible with every device or platform.
        </p>
      </LegalSection>

      <LegalSection title="No Responsibility for Misuse">
        <p>
          The developers of {siteConfig.name} are not responsible for any misuse of the App,
          including the downloading, distribution, or use of content in violation of applicable
          copyright laws or third-party rights.
        </p>
      </LegalSection>

      <LegalSection title="Third-Party Platforms">
        <p>
          {siteConfig.name} is not affiliated with, endorsed by, or sponsored by any third-party
          platform. Availability of downloads may change at any time based on decisions made by
          those platforms.
        </p>
      </LegalSection>

      <LegalSection title="Contact">
        <p>
          If you have questions about this Disclaimer, contact us at{" "}
          <a href={`mailto:${siteConfig.contactEmail}`} className="text-blue-accent hover:underline">
            {siteConfig.contactEmail}
          </a>
          .
        </p>
      </LegalSection>
    </LegalPage>
  );
}
