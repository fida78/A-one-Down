import Link from "next/link";

export default function NotFound() {
  return (
    <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden py-20">
      <div className="absolute inset-0 bg-gradient-radial-glow pointer-events-none" />
      <div className="container-page relative text-center flex flex-col items-center">
        <div className="relative mb-8">
          <p className="font-display text-[7rem] sm:text-[9rem] leading-none font-semibold text-gradient animate-float-slow select-none">
            404
          </p>
          <div className="absolute left-1/2 -translate-x-1/2 -bottom-4 w-40 h-2 rounded-full bg-ink-line blur-sm" />
        </div>
        <h1 className="font-display text-2xl sm:text-3xl font-semibold text-white mb-3">
          This link didn't download anything
        </h1>
        <p className="text-white/55 max-w-md mb-10">
          The page you're looking for doesn't exist or may have moved. Let's get you back on track.
        </p>
        <Link href="/" className="btn-primary">
          ← Back to Home
        </Link>
      </div>
    </section>
  );
}
