import type { Metadata } from "next";
import HelpCenterClient from "./HelpCenterClient";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Help Center",
  description: `Find answers about installing, using, and troubleshooting ${siteConfig.name}, the Android video downloader.`,
};

export default function HelpCenterPage() {
  return <HelpCenterClient />;
}
