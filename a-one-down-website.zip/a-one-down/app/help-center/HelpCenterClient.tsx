"use client";

import { useMemo, useState } from "react";
import SectionHeading from "@/components/SectionHeading";

type Article = {
  category: string;
  question: string;
  answer: string;
};

const articles: Article[] = [
  {
    category: "Installation",
    question: "How do I install the A One Down APK?",
    answer:
      "Download the APK file from the official website, open your device's file manager or downloads notification, tap the file, and follow the on-screen prompts to install it.",
  },
  {
    category: "Installation",
    question: "Why does my phone warn me about installing from unknown sources?",
    answer:
      "Android shows this warning for any app installed outside the Google Play Store. This is a standard Android security check. Enable 'Install unknown apps' for your browser or file manager to proceed.",
  },
  {
    category: "Installation",
    question: "Is the APK safe to install?",
    answer:
      "Only download the APK from our official website to ensure you're getting an unmodified, safe copy of the app.",
  },
  {
    category: "Installation",
    question: "What Android version do I need?",
    answer:
      "A One Down is built to run on modern versions of Android. If installation fails, check that your device meets the minimum Android version listed on the download page.",
  },
  {
    category: "Download Problems",
    question: "Why did my download fail?",
    answer:
      "Downloads can fail due to an unstable internet connection, a link that has been removed or made private, or a source website that restricts downloading.",
  },
  {
    category: "Download Problems",
    question: "Why can't I download from a certain link?",
    answer:
      "Some websites use technologies or restrictions that prevent downloading. If a link doesn't work, try a different public video link.",
  },
  {
    category: "Download Problems",
    question: "The app says 'unable to process link' — what does this mean?",
    answer:
      "This usually means the link is private, invalid, or from a platform that isn't currently supported.",
  },
  {
    category: "Download Problems",
    question: "Can I download private or restricted videos?",
    answer:
      "No. A One Down only works with publicly available videos that you have permission to access.",
  },
  {
    category: "Storage",
    question: "Where are my downloaded videos saved?",
    answer:
      "Downloaded videos are saved locally on your device and can be found in the app's Downloads section or your device's file storage, typically in a folder created by the app.",
  },
  {
    category: "Storage",
    question: "Can I move downloaded videos to another app?",
    answer:
      "Yes. Since files are saved to your device storage, you can move, share, or open them using any compatible app on your phone.",
  },
  {
    category: "Storage",
    question: "Why am I running out of storage space?",
    answer:
      "Video files can be large, especially in HD. Regularly review your Downloads section and remove files you no longer need.",
  },
  {
    category: "Slow Downloads",
    question: "Why is my download so slow?",
    answer:
      "Download speed largely depends on your internet connection quality and the source server's speed. Try switching between Wi-Fi and mobile data to see which performs better.",
  },
  {
    category: "Slow Downloads",
    question: "Does video quality affect download speed?",
    answer:
      "Yes. Higher quality videos are larger in file size and will take longer to download than lower quality options.",
  },
  {
    category: "Slow Downloads",
    question: "Should I close other apps to speed up downloads?",
    answer:
      "Closing apps that use significant bandwidth in the background can help free up your connection for a faster download.",
  },
  {
    category: "App Updates",
    question: "How do I update A One Down?",
    answer:
      "Visit our official website, download the latest APK version, and install it over your existing app. Your downloaded videos and settings will not be affected.",
  },
  {
    category: "App Updates",
    question: "Will updating delete my downloaded videos?",
    answer:
      "No. Downloaded videos are stored separately in your device storage and are not affected by app updates.",
  },
  {
    category: "App Updates",
    question: "How do I know if a new update is available?",
    answer:
      "Check the official website periodically, or enable notifications if the app offers update alerts.",
  },
  {
    category: "Frequently Asked Questions",
    question: "Is A One Down free?",
    answer: "Yes. A One Down is free to download and use.",
  },
  {
    category: "Frequently Asked Questions",
    question: "Is login required?",
    answer: "No. The app does not require account registration.",
  },
  {
    category: "Frequently Asked Questions",
    question: "Is internet required?",
    answer: "Yes. Internet is required to retrieve downloadable video information.",
  },
  {
    category: "Frequently Asked Questions",
    question: "Does the app store my videos on its servers?",
    answer: "No. Downloaded videos remain on your device only.",
  },
  {
    category: "Frequently Asked Questions",
    question: "Is my personal data collected?",
    answer: "The app collects only limited technical information necessary for app functionality and analytics.",
  },
];

const categories = [
  "All",
  "Installation",
  "Download Problems",
  "Storage",
  "Slow Downloads",
  "App Updates",
  "Frequently Asked Questions",
];

export default function HelpCenterClient() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const filtered = useMemo(() => {
    return articles.filter((a) => {
      const matchesCategory = activeCategory === "All" || a.category === activeCategory;
      const matchesQuery =
        query.trim().length === 0 ||
        a.question.toLowerCase().includes(query.toLowerCase()) ||
        a.answer.toLowerCase().includes(query.toLowerCase());
      return matchesCategory && matchesQuery;
    });
  }, [query, activeCategory]);

  return (
    <section className="py-20 sm:py-28">
      <div className="container-page">
        <SectionHeading
          eyebrow="Help Center"
          title="How can we help?"
          subtitle="Search for answers or browse by category."
        />

        <div className="max-w-xl mx-auto mb-10">
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30">⌕</span>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search help articles…"
              className="w-full rounded-xl border border-ink-line bg-ink-panel pl-11 pr-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-blue-accent outline-none transition-colors"
            />
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => setActiveCategory(c)}
              className={`text-xs font-medium px-4 py-2 rounded-full border transition-colors ${
                activeCategory === c
                  ? "border-blue-accent bg-blue-accent/15 text-white"
                  : "border-ink-line text-white/55 hover:border-white/30"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="max-w-2xl mx-auto flex flex-col gap-3">
          {filtered.length === 0 && (
            <p className="text-center text-white/40 text-sm py-10">
              No articles matched your search. Try a different term.
            </p>
          )}
          {filtered.map((a) => (
            <div key={a.question} className="card-surface p-5">
              <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-signal">
                {a.category}
              </span>
              <h3 className="font-display font-semibold text-white mt-1.5 mb-2">{a.question}</h3>
              <p className="text-sm text-white/55 leading-relaxed">{a.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
