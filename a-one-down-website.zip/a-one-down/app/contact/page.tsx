import type { Metadata } from "next";
import ContactClient from "./ContactClient";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Contact Us",
  description: `Get in touch with the ${siteConfig.name} team for support, feedback, or questions.`,
};

export default function ContactPage() {
  return <ContactClient />;
}
