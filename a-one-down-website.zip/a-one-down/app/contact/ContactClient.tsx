"use client";

import { useState } from "react";
import SectionHeading from "@/components/SectionHeading";
import { siteConfig } from "@/lib/site-config";

export default function ContactClient() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section className="py-20 sm:py-28">
      <div className="container-page">
        <SectionHeading
          eyebrow="Contact Us"
          title="We'd love to hear from you"
          subtitle="Send us a message and our team will get back to you."
        />

        <div className="grid lg:grid-cols-[1fr_1.2fr] gap-10 max-w-4xl mx-auto">
          <div className="flex flex-col gap-5">
            <div className="card-surface p-6">
              <p className="text-xs font-mono uppercase tracking-widest text-cyan-signal mb-2">
                Support Email
              </p>
              <a href={`mailto:${siteConfig.supportEmail}`} className="text-white font-medium hover:text-blue-accent transition-colors">
                {siteConfig.supportEmail}
              </a>
            </div>
            <div className="card-surface p-6">
              <p className="text-xs font-mono uppercase tracking-widest text-cyan-signal mb-2">
                Website
              </p>
              <p className="text-white font-medium">{siteConfig.websiteDisplay}</p>
            </div>
            <div className="card-surface p-6">
              <p className="text-xs font-mono uppercase tracking-widest text-cyan-signal mb-2">
                Expected Response Time
              </p>
              <p className="text-white font-medium">24–48 business hours</p>
            </div>
          </div>

          <div className="card-surface p-6 sm:p-8">
            {submitted ? (
              <div className="flex flex-col items-center justify-center text-center py-12 gap-3">
                <div className="h-12 w-12 rounded-full bg-cyan-signal/15 border border-cyan-signal/40 flex items-center justify-center text-xl text-cyan-signal">
                  ✓
                </div>
                <h3 className="font-display font-semibold text-white text-lg">Message sent</h3>
                <p className="text-sm text-white/55 max-w-xs">
                  Thanks for reaching out. Our team will respond within 24–48 business hours.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                <div>
                  <label htmlFor="name" className="block text-sm text-white/70 mb-2">
                    Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    className="w-full rounded-xl border border-ink-line bg-ink-panel px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-blue-accent outline-none transition-colors"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm text-white/70 mb-2">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    className="w-full rounded-xl border border-ink-line bg-ink-panel px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-blue-accent outline-none transition-colors"
                    placeholder="you@example.com"
                  />
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm text-white/70 mb-2">
                    Subject
                  </label>
                  <input
                    id="subject"
                    name="subject"
                    type="text"
                    required
                    className="w-full rounded-xl border border-ink-line bg-ink-panel px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-blue-accent outline-none transition-colors"
                    placeholder="How can we help?"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm text-white/70 mb-2">
                    Message
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={5}
                    className="w-full rounded-xl border border-ink-line bg-ink-panel px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-blue-accent outline-none transition-colors resize-none"
                    placeholder="Tell us more…"
                  />
                </div>
                <button type="submit" className="btn-primary w-full sm:w-auto self-start">
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
