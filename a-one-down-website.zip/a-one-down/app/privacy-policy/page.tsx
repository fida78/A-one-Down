import type { Metadata } from "next";
import LegalPage, { LegalSection } from "@/components/LegalPage";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: `Read the Privacy Policy for ${siteConfig.name}, covering what information is collected, how it is used, and your rights.`,
};

export default function PrivacyPolicyPage() {
  return (
    <LegalPage title="Privacy Policy" updated="January 1, 2026">
      <p>
        This Privacy Policy explains how {siteConfig.name} ("the app," "we," "us") handles
        information when you use our Android application. By using {siteConfig.name}, you agree
        to the practices described in this policy.
      </p>

      <LegalSection title="Information We Collect">
        <p>{siteConfig.name} does not require account registration to use the app.</p>
        <p>The app may collect the following limited technical information:</p>
        <ul className="list-disc list-inside flex flex-col gap-1.5 marker:text-blue-accent">
          <li>Device model</li>
          <li>Android version</li>
          <li>Crash reports</li>
          <li>App version</li>
          <li>Anonymous analytics</li>
          <li>Advertising identifiers (if ads are enabled)</li>
        </ul>
        <p>We do not intentionally collect the following:</p>
        <ul className="list-disc list-inside flex flex-col gap-1.5 marker:text-blue-accent">
          <li>Photos</li>
          <li>Videos</li>
          <li>Contacts</li>
          <li>Messages</li>
          <li>Passwords</li>
          <li>Financial information</li>
          <li>Personal identity information</li>
        </ul>
      </LegalSection>

      <LegalSection title="Permissions">
        <p>{siteConfig.name} requests only the permissions necessary for the app to function:</p>
        <ul className="list-disc list-inside flex flex-col gap-1.5 marker:text-blue-accent">
          <li><span className="text-white/85">Internet</span> — required to retrieve information about a pasted video link and to download the video file.</li>
          <li><span className="text-white/85">Network State</span> — used to check connectivity before starting a download.</li>
          <li><span className="text-white/85">Notifications</span> (if supported) — used to inform you of download progress and completion.</li>
          <li><span className="text-white/85">Storage access</span> — requested only when necessary to save downloaded files to your device.</li>
        </ul>
        <p>These permissions are used solely for app functionality and are not used to access unrelated content on your device.</p>
      </LegalSection>

      <LegalSection title="Downloaded Content">
        <p>
          Downloaded files are stored locally on your device. We do not upload downloaded videos
          to our servers, and we do not retain copies of any content you download.
        </p>
      </LegalSection>

      <LegalSection title="Advertising">
        <p>
          The app may display advertisements from trusted advertising partners. Advertising
          partners may use anonymous identifiers to provide relevant advertisements. We do not
          share personally identifying information with advertising partners.
        </p>
      </LegalSection>

      <LegalSection title="Security">
        <p>
          We use reasonable technical and organizational measures to protect app data. However,
          no method of electronic storage or transmission is completely secure, and we cannot
          guarantee absolute security.
        </p>
      </LegalSection>

      <LegalSection title="Children's Privacy">
        <p>
          {siteConfig.name} is not intended for children under 13 years of age. We do not
          knowingly collect information from children under 13.
        </p>
      </LegalSection>

      <LegalSection title="User Responsibilities">
        <p>
          You are responsible for ensuring that you have permission to download and use any
          content accessed through the app. Please respect copyright laws and the terms of
          service of the platforms you use.
        </p>
      </LegalSection>

      <LegalSection title="Changes to This Policy">
        <p>
          This Privacy Policy may be updated periodically. Continued use of the app after changes
          are posted constitutes acceptance of the revised policy.
        </p>
      </LegalSection>

      <LegalSection title="Contact">
        <p>
          If you have questions about this Privacy Policy, contact us at{" "}
          <a href={`mailto:${siteConfig.contactEmail}`} className="text-blue-accent hover:underline">
            {siteConfig.contactEmail}
          </a>
          .
        </p>
      </LegalSection>
    </LegalPage>
  );
}
