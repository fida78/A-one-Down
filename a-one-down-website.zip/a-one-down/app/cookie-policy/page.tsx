import type { Metadata } from "next";
import LegalPage, { LegalSection } from "@/components/LegalPage";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Cookie Policy",
  description: `Learn how ${siteConfig.name} uses cookies on this website and how you can manage them.`,
};

export default function CookiePolicyPage() {
  return (
    <LegalPage title="Cookie Policy" updated="January 1, 2026">
      <p>
        This Cookie Policy explains how {siteConfig.name} uses cookies and similar technologies
        on our website to provide, secure, and improve your browsing experience.
      </p>

      <LegalSection title="Essential Cookies">
        <p>
          These cookies are necessary for the website to function properly. They enable core
          features such as page navigation and secure access, and cannot be disabled without
          affecting how the site works.
        </p>
      </LegalSection>

      <LegalSection title="Analytics Cookies">
        <p>
          Analytics cookies help us understand how visitors interact with our website, such as
          which pages are viewed most often. This information is used only to improve the website
          and is collected in an anonymous, aggregated form.
        </p>
      </LegalSection>

      <LegalSection title="Preference Cookies">
        <p>
          Preference cookies remember choices you've made on the website, such as display
          settings, to provide a more personalized experience on future visits.
        </p>
      </LegalSection>

      <LegalSection title="Managing Cookies">
        <p>
          You can manage or disable cookies at any time through your browser settings. Most
          browsers allow you to refuse cookies, delete existing cookies, or receive a notification
          before a cookie is stored. Please note that disabling certain cookies may affect the
          functionality of this website.
        </p>
      </LegalSection>

      <LegalSection title="Contact">
        <p>
          If you have questions about this Cookie Policy, contact us at{" "}
          <a href={`mailto:${siteConfig.contactEmail}`} className="text-blue-accent hover:underline">
            {siteConfig.contactEmail}
          </a>
          .
        </p>
      </LegalSection>
    </LegalPage>
  );
}
