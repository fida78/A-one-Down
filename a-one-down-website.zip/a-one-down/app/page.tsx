import PhoneMockup from "@/components/PhoneMockup";
import SectionHeading from "@/components/SectionHeading";
import FeatureCard from "@/components/FeatureCard";
import StepCard from "@/components/StepCard";
import ScreenshotsSlider from "@/components/ScreenshotsSlider";
import FaqAccordion, { FaqItem } from "@/components/FaqAccordion";
import { siteConfig } from "@/lib/site-config";

const features = [
  { icon: "⚡", title: "Fast Downloads", description: "Optimized download handling gets your video saved in as few steps as possible." },
  { icon: "🎬", title: "HD Video Support", description: "Save videos in high definition when the source provides an HD option." },
  { icon: "📋", title: "Easy Link Paste", description: "Copy a public video link and paste it straight into the app to get started." },
  { icon: "📥", title: "Built-in Download Manager", description: "Track active and completed downloads from one organized screen." },
  { icon: "🧭", title: "Simple Interface", description: "A clean, uncluttered layout that's easy to use the very first time." },
  { icon: "🪶", title: "Lightweight App", description: "A small install size that runs smoothly without weighing down your device." },
  { icon: "🔒", title: "Secure Downloads", description: "Files are processed and saved without unnecessary access to your data." },
  { icon: "🔄", title: "Regular Updates", description: "Ongoing improvements keep the app working reliably over time." },
  { icon: "🚀", title: "Quick Performance", description: "A responsive experience built for speed on everyday Android devices." },
  { icon: "🤖", title: "Android Optimized", description: "Built specifically for Android, tuned to fit the platform's behavior." },
];

const steps = [
  { icon: "🔗", title: "Copy the video link", description: "Open the supported website or app and copy the public video link." },
  { icon: "📱", title: "Open A One Down", description: "Launch the app on your Android device." },
  { icon: "📋", title: "Paste the link", description: "Paste the copied link into the search box inside the app." },
  { icon: "⏳", title: "Let it process", description: "Allow the app a moment to process the link and read video details." },
  { icon: "🎚️", title: "Choose your quality", description: "Select the available quality if the video offers more than one option." },
  { icon: "⬇️", title: "Tap Download", description: "Start the download with a single tap." },
  { icon: "📊", title: "Wait for it to finish", description: "Keep the app open until the download completes." },
  { icon: "📂", title: "Find your file", description: "Access your downloaded file from the app's Downloads section or your device storage." },
];

const faqs: FaqItem[] = [
  { question: "Is A One Down free?", answer: "Yes. A One Down is free to download and use." },
  { question: "Is login required?", answer: "No. The app does not require account registration." },
  { question: "Is internet required?", answer: "Yes. Internet is required to retrieve downloadable video information." },
  { question: "Does the app store my videos?", answer: "No. Downloaded videos remain on your device." },
  { question: "Is my personal data collected?", answer: "The app collects only limited technical information necessary for app functionality and analytics." },
  { question: "Why can't some links be downloaded?", answer: "Some websites restrict downloads or use technologies that are not supported." },
  { question: "How do I update the app?", answer: "Download the latest APK from the official website." },
];

const jsonLdApp = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: siteConfig.name,
  applicationCategory: "MultimediaApplication",
  operatingSystem: "Android",
  description: siteConfig.description,
  offers: {
    "@type": "Offer",
    price: "0",
    priceCurrency: "USD",
  },
};

const jsonLdFaq = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((f) => ({
    "@type": "Question",
    name: f.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: f.answer,
    },
  })),
};

export default function HomePage() {
  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdApp) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdFaq) }}
      />
      {/* HERO */}
      <section className="relative overflow-hidden pt-16 pb-24 sm:pt-24 sm:pb-32">
        <div className="absolute inset-0 bg-gradient-radial-glow pointer-events-none" />
        <div className="container-page relative grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <span className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-cyan-signal border border-cyan-signal/30 bg-cyan-signal/5 rounded-full px-3 py-1.5 mb-6">
              Android · Free App
            </span>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-[3.25rem] leading-[1.1] font-semibold text-white">
              Download Videos <span className="text-gradient">Faster</span> with A One Down
            </h1>
            <p className="mt-6 text-lg text-white/60 leading-relaxed max-w-lg">
              {siteConfig.description}
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <a href={siteConfig.apkDownloadUrl} className="btn-primary">
                <span>⬇</span> Download APK
              </a>
              <a href="#how-it-works" className="btn-secondary">
                See How It Works
              </a>
            </div>
            <p className="mt-6 text-xs text-white/35 max-w-md leading-relaxed">
              For publicly available videos on supported platforms. Users are responsible for
              ensuring they have permission to download and use any content.
            </p>
          </div>

          <PhoneMockup />
        </div>
      </section>

      <div className="container-page">
        <div className="progress-divider" />
      </div>

      {/* FEATURES */}
      <section id="features" className="py-24">
        <div className="container-page">
          <SectionHeading
            eyebrow="Features"
            title="Everything you need, nothing you don't"
            subtitle="A One Down keeps things fast and simple — built to do one job well."
          />
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f) => (
              <FeatureCard key={f.title} {...f} />
            ))}
          </div>
        </div>
      </section>

      {/* SCREENSHOTS */}
      <section className="py-24 bg-ink-panel/40">
        <div className="container-page">
          <SectionHeading
            eyebrow="Take a look"
            title="A closer look at the app"
            subtitle="A quick tour through the core screens — from pasting a link to finding your download."
          />
          <ScreenshotsSlider />
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section id="how-it-works" className="py-24">
        <div className="container-page">
          <SectionHeading
            eyebrow="How It Works"
            title="From link to download in a few taps"
            subtitle="A One Down is designed around one simple flow."
          />
          <div className="max-w-xl mx-auto">
            {steps.map((s, i) => (
              <StepCard key={s.title} number={i + 1} {...s} isLast={i === steps.length - 1} />
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24 bg-ink-panel/40">
        <div className="container-page">
          <SectionHeading eyebrow="FAQ" title="Frequently asked questions" />
          <div className="max-w-2xl mx-auto">
            <FaqAccordion items={faqs} />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24">
        <div className="container-page">
          <div className="relative card-surface p-10 sm:p-16 text-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-radial-glow pointer-events-none" />
            <div className="relative">
              <h2 className="font-display text-3xl sm:text-4xl font-semibold text-white">
                Ready to download faster?
              </h2>
              <p className="mt-4 text-white/55 max-w-md mx-auto">
                Get A One Down on your Android device and start downloading in minutes.
              </p>
              <a href={siteConfig.apkDownloadUrl} className="btn-primary mt-8">
                <span>⬇</span> Download APK Now
              </a>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
