import type { Metadata } from "next";
import LegalPage, { LegalSection } from "@/components/LegalPage";
import { siteConfig } from "@/lib/site-config";

export const metadata: Metadata = {
  title: "Terms of Use",
  description: `The Terms of Use governing your access to and use of ${siteConfig.name}.`,
};

export default function TermsOfUsePage() {
  return (
    <LegalPage title="Terms of Use" updated="January 1, 2026">
      <p>
        These Terms of Use ("Terms") govern your access to and use of {siteConfig.name} (the
        "App"). By downloading, installing, or using the App, you agree to be bound by these
        Terms. If you do not agree, please do not use the App.
      </p>

      <LegalSection title="1. Acceptance of Terms">
        <p>
          By installing or using {siteConfig.name}, you confirm that you have read, understood,
          and agree to these Terms, along with our Privacy Policy and Disclaimer.
        </p>
      </LegalSection>

      <LegalSection title="2. Lawful Use">
        <p>
          You agree to use the App only for lawful purposes. You must not use the App to access,
          download, or distribute content in violation of any applicable law or third-party
          rights.
        </p>
      </LegalSection>

      <LegalSection title="3. Copyright Compliance">
        <p>
          {siteConfig.name} does not host, store, or distribute copyrighted content. The App is a
          tool that allows users to download publicly available videos from supported platforms
          when the user has the right to do so. You must only download content that you own, that
          is in the public domain, or that you otherwise have explicit permission to download and
          use.
        </p>
      </LegalSection>

      <LegalSection title="4. User Responsibilities">
        <p>
          You are solely responsible for the content you choose to download and how you use it.
          This includes ensuring you have the necessary rights or permissions and complying with
          the terms of service of any platform from which content originates.
        </p>
      </LegalSection>

      <LegalSection title="5. Intellectual Property">
        <p>
          The App, including its design, branding, and underlying software, is the property of
          {" "}{siteConfig.name} and its developers. These Terms do not grant you any rights to our
          trademarks, logos, or brand assets beyond what is necessary to use the App as intended.
          All third-party content remains the property of its respective owners.
        </p>
      </LegalSection>

      <LegalSection title="6. Limitation of Liability">
        <p>
          To the maximum extent permitted by law, {siteConfig.name} and its developers shall not
          be liable for any indirect, incidental, special, or consequential damages arising from
          your use or inability to use the App, including but not limited to loss of data or
          content obtained through third-party platforms.
        </p>
      </LegalSection>

      <LegalSection title="7. Disclaimer">
        <p>
          The App is provided "as is" and "as available," without warranties of any kind, either
          express or implied, including but not limited to warranties of merchantability, fitness
          for a particular purpose, or non-infringement.
        </p>
      </LegalSection>

      <LegalSection title="8. App Availability">
        <p>
          We do not guarantee that the App will always be available, uninterrupted, or free of
          errors. Availability may depend on factors outside our control, including third-party
          platform changes.
        </p>
      </LegalSection>

      <LegalSection title="9. Updates">
        <p>
          We may release updates to the App from time to time to improve functionality, security,
          or compatibility. The latest version of the App is available for download from our
          official website.
        </p>
      </LegalSection>

      <LegalSection title="10. Account">
        <p>
          {siteConfig.name} does not require account registration. No personal account is created
          or needed to use the App's features.
        </p>
      </LegalSection>

      <LegalSection title="11. Governing Law">
        <p>
          These Terms shall be governed by and construed in accordance with applicable local laws,
          without regard to conflict of law principles.
        </p>
      </LegalSection>

      <LegalSection title="12. Contact Information">
        <p>
          For questions about these Terms, contact us at{" "}
          <a href={`mailto:${siteConfig.contactEmail}`} className="text-blue-accent hover:underline">
            {siteConfig.contactEmail}
          </a>
          .
        </p>
      </LegalSection>
    </LegalPage>
  );
}
