import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#08080C",
          panel: "#111116",
          raised: "#17171F",
          line: "#232330",
        },
        blue: {
          accent: "#4F7CFF",
        },
        violet: {
          accent: "#9B5CFF",
        },
        cyan: {
          signal: "#22D3EE",
        },
      },
      fontFamily: {
        display: ["var(--font-space-grotesk)", "sans-serif"],
        body: ["var(--font-inter)", "sans-serif"],
        mono: ["var(--font-jetbrains-mono)", "monospace"],
      },
      backgroundImage: {
        "gradient-primary": "linear-gradient(135deg, #4F7CFF 0%, #9B5CFF 100%)",
        "gradient-radial-glow":
          "radial-gradient(circle at 50% 0%, rgba(79,124,255,0.18) 0%, rgba(155,92,255,0.08) 35%, rgba(8,8,12,0) 70%)",
        "gradient-line": "linear-gradient(90deg, #4F7CFF 0%, #22D3EE 50%, #9B5CFF 100%)",
      },
      animation: {
        "fill-bar": "fillBar 2.4s ease-in-out infinite",
        "float-slow": "floatSlow 6s ease-in-out infinite",
        "fade-up": "fadeUp 0.7s ease-out forwards",
        "pulse-glow": "pulseGlow 3s ease-in-out infinite",
        marquee: "marquee 30s linear infinite",
      },
      keyframes: {
        fillBar: {
          "0%": { width: "0%" },
          "45%": { width: "100%" },
          "70%": { width: "100%" },
          "100%": { width: "0%" },
        },
        floatSlow: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-14px)" },
        },
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(24px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        pulseGlow: {
          "0%, 100%": { opacity: "0.5" },
          "50%": { opacity: "1" },
        },
        marquee: {
          "0%": { transform: "translateX(0%)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
