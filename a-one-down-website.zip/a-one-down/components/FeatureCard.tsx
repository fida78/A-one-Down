export default function FeatureCard({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="card-surface p-6 transition-transform duration-300 hover:-translate-y-1.5 hover:border-blue-accent/50 group">
      <div className="h-11 w-11 rounded-xl bg-gradient-primary/20 border border-blue-accent/30 flex items-center justify-center text-lg mb-4 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="font-display font-semibold text-white mb-2">{title}</h3>
      <p className="text-sm text-white/55 leading-relaxed">{description}</p>
    </div>
  );
}
