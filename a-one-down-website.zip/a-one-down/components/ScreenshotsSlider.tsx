"use client";

import { useRef } from "react";

const screens = [
  { title: "Home", desc: "Paste a link and go", accent: "#4F7CFF" },
  { title: "Link Detected", desc: "Video information loaded", accent: "#22D3EE" },
  { title: "Quality Select", desc: "Pick the resolution you want", accent: "#9B5CFF" },
  { title: "Downloading", desc: "Track progress in real time", accent: "#4F7CFF" },
  { title: "Downloads", desc: "All your files, organized", accent: "#22D3EE" },
];

export default function ScreenshotsSlider() {
  const trackRef = useRef<HTMLDivElement>(null);

  const scrollBy = (dir: number) => {
    trackRef.current?.scrollBy({ left: dir * 260, behavior: "smooth" });
  };

  return (
    <div className="relative">
      <div
        ref={trackRef}
        className="flex gap-5 overflow-x-auto snap-x snap-mandatory pb-4 scrollbar-hide"
        style={{ scrollbarWidth: "none" }}
      >
        {screens.map((s) => (
          <div
            key={s.title}
            className="snap-center shrink-0 w-[220px] sm:w-[240px] rounded-[1.75rem] border border-ink-line bg-ink-panel p-3"
          >
            <div className="rounded-[1.25rem] bg-[#0c0c12] border border-ink-line aspect-[9/18] flex flex-col items-center justify-center gap-3 p-4 relative overflow-hidden">
              <div
                className="absolute inset-x-6 top-6 h-1.5 rounded-full"
                style={{ backgroundColor: s.accent, opacity: 0.25 }}
              />
              <div
                className="h-14 w-14 rounded-2xl flex items-center justify-center text-xl"
                style={{ backgroundColor: `${s.accent}22`, border: `1px solid ${s.accent}55`, color: s.accent }}
              >
                ▶
              </div>
              <p className="font-display text-sm font-semibold text-white text-center">{s.title}</p>
              <p className="text-xs text-white/45 text-center leading-relaxed">{s.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center gap-3 mt-4">
        <button
          aria-label="Scroll screenshots left"
          onClick={() => scrollBy(-1)}
          className="h-9 w-9 rounded-full border border-ink-line flex items-center justify-center text-white/60 hover:border-blue-accent hover:text-white transition-colors"
        >
          ←
        </button>
        <button
          aria-label="Scroll screenshots right"
          onClick={() => scrollBy(1)}
          className="h-9 w-9 rounded-full border border-ink-line flex items-center justify-center text-white/60 hover:border-blue-accent hover:text-white transition-colors"
        >
          →
        </button>
      </div>
    </div>
  );
}
