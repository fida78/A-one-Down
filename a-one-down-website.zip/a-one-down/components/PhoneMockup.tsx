"use client";

import { useEffect, useState } from "react";

type Stage = "paste" | "processing" | "quality" | "downloading" | "done";

const STAGE_DURATIONS: Record<Stage, number> = {
  paste: 1400,
  processing: 1200,
  quality: 1300,
  downloading: 2200,
  done: 1600,
};

const STAGE_ORDER: Stage[] = ["paste", "processing", "quality", "downloading", "done"];

export default function PhoneMockup() {
  const [stage, setStage] = useState<Stage>("paste");
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const idx = STAGE_ORDER.indexOf(stage);
    const timer = setTimeout(() => {
      const next = STAGE_ORDER[(idx + 1) % STAGE_ORDER.length];
      setStage(next);
    }, STAGE_DURATIONS[stage]);
    return () => clearTimeout(timer);
  }, [stage]);

  useEffect(() => {
    if (stage !== "downloading") {
      setProgress(0);
      return;
    }
    setProgress(0);
    const start = Date.now();
    const duration = STAGE_DURATIONS.downloading - 200;
    const interval = setInterval(() => {
      const elapsed = Date.now() - start;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);
      if (pct >= 100) clearInterval(interval);
    }, 50);
    return () => clearInterval(interval);
  }, [stage]);

  return (
    <div className="relative mx-auto w-[260px] sm:w-[290px] animate-float-slow">
      {/* ambient glow */}
      <div className="absolute -inset-10 bg-gradient-radial-glow blur-2xl -z-10" />

      {/* phone frame */}
      <div className="relative rounded-[2.5rem] border-[6px] border-[#1c1c26] bg-[#0c0c12] shadow-2xl shadow-black/60 overflow-hidden">
        <div className="absolute top-0 inset-x-0 h-6 flex items-center justify-center">
          <div className="h-4 w-24 rounded-b-xl bg-[#0c0c12] border-x border-b border-[#1c1c26]" />
        </div>

        <div className="pt-8 pb-6 px-4 min-h-[540px] flex flex-col">
          <div className="text-center mb-4">
            <p className="font-display text-sm font-semibold text-white/90">A One Down</p>
          </div>

          {/* URL input row */}
          <div className="rounded-xl border border-ink-line bg-ink-panel px-3 py-2.5 flex items-center gap-2 mb-4">
            <span className="text-white/30 text-xs">🔗</span>
            <span className="text-xs text-white/60 font-mono truncate">
              {stage === "paste" ? "" : "https://example.com/video/8841"}
            </span>
            <span
              className={`ml-auto h-1.5 w-1.5 rounded-full bg-cyan-signal ${
                stage === "paste" ? "animate-pulse-glow" : "opacity-0"
              }`}
            />
          </div>

          {/* dynamic content area */}
          <div className="flex-1 flex flex-col items-center justify-center gap-4">
            {stage === "paste" && (
              <div className="text-center text-white/35 text-xs px-4 animate-fade-up">
                Paste a public video link to begin
              </div>
            )}

            {stage === "processing" && (
              <div className="flex flex-col items-center gap-3 animate-fade-up">
                <div className="h-9 w-9 rounded-full border-2 border-blue-accent/30 border-t-blue-accent animate-spin" />
                <p className="text-xs text-white/50">Reading video information…</p>
              </div>
            )}

            {stage === "quality" && (
              <div className="w-full flex flex-col gap-2 animate-fade-up">
                <p className="text-[11px] text-white/40 mb-1">Choose quality</p>
                {["1080p HD", "720p", "480p"].map((q, i) => (
                  <div
                    key={q}
                    className={`rounded-lg border px-3 py-2 text-xs flex items-center justify-between font-mono ${
                      i === 0
                        ? "border-blue-accent bg-blue-accent/10 text-white"
                        : "border-ink-line text-white/50"
                    }`}
                  >
                    <span>{q}</span>
                    {i === 0 && <span className="text-cyan-signal">✓</span>}
                  </div>
                ))}
              </div>
            )}

            {stage === "downloading" && (
              <div className="w-full flex flex-col items-center gap-3 animate-fade-up">
                <p className="text-xs text-white/50">Downloading…</p>
                <div className="w-full h-2 rounded-full bg-ink-line overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-primary transition-[width] duration-100 ease-linear"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <p className="text-[11px] font-mono text-white/40">{progress}%</p>
              </div>
            )}

            {stage === "done" && (
              <div className="flex flex-col items-center gap-3 animate-fade-up">
                <div className="h-12 w-12 rounded-full bg-cyan-signal/15 border border-cyan-signal/40 flex items-center justify-center">
                  <span className="text-cyan-signal text-xl">✓</span>
                </div>
                <p className="text-xs text-white/70">Saved to Downloads</p>
              </div>
            )}
          </div>

          <div className="mt-auto pt-4 border-t border-ink-line flex justify-center">
            <div className="h-1 w-16 rounded-full bg-white/15" />
          </div>
        </div>
      </div>
    </div>
  );
}
