import Link from "next/link";
import { footerLinks, siteConfig } from "@/lib/site-config";

export default function Footer() {
  return (
    <footer className="border-t border-ink-line mt-24">
      <div className="progress-divider" />
      <div className="container-page py-14">
        <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-10">
          <div className="max-w-sm">
            <Link href="/" className="flex items-center gap-2 font-display font-semibold text-lg">
              <span className="inline-flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary text-white text-sm">
                1↓
              </span>
              <span>{siteConfig.name}</span>
            </Link>
            <p className="mt-4 text-sm text-white/55 leading-relaxed">
              A fast, lightweight Android video downloader for publicly available videos on
              supported platforms. Simple to use, no account required.
            </p>
          </div>

          <nav aria-label="Footer navigation" className="grid grid-cols-2 gap-x-10 gap-y-3 text-sm">
            {footerLinks.map((link) => (
              <Link key={link.href} href={link.href} className="text-white/60 hover:text-white transition-colors">
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        <div className="mt-12 pt-6 border-t border-ink-line flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-white/40">
          <p>© {siteConfig.year} {siteConfig.name}. All Rights Reserved.</p>
          <p>Users are responsible for respecting copyright and platform terms.</p>
        </div>
      </div>
    </footer>
  );
}
