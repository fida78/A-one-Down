export default function StepCard({
  number,
  title,
  description,
  icon,
  isLast = false,
}: {
  number: number;
  title: string;
  description: string;
  icon: React.ReactNode;
  isLast?: boolean;
}) {
  return (
    <div className="relative flex gap-5">
      <div className="flex flex-col items-center">
        <div className="h-12 w-12 shrink-0 rounded-xl bg-ink-panel border border-ink-line flex items-center justify-center text-xl relative">
          {icon}
          <span className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-gradient-primary text-[10px] font-mono flex items-center justify-center text-white">
            {number}
          </span>
        </div>
        {!isLast && <div className="w-px flex-1 bg-gradient-to-b from-blue-accent/40 to-transparent mt-2 mb-2" />}
      </div>
      <div className={isLast ? "pb-0" : "pb-10"}>
        <h3 className="font-display font-semibold text-white mb-1.5">{title}</h3>
        <p className="text-sm text-white/55 leading-relaxed max-w-md">{description}</p>
      </div>
    </div>
  );
}
