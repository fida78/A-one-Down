export default function SectionHeading({
  eyebrow,
  title,
  subtitle,
  align = "center",
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  align?: "center" | "left";
}) {
  return (
    <div className={`max-w-2xl ${align === "center" ? "mx-auto text-center" : "text-left"} mb-14`}>
      {eyebrow && (
        <span className="inline-block text-xs font-mono tracking-widest uppercase text-cyan-signal mb-3">
          {eyebrow}
        </span>
      )}
      <h2 className="font-display text-3xl sm:text-4xl font-semibold text-white">{title}</h2>
      {subtitle && <p className="mt-4 text-white/55 leading-relaxed">{subtitle}</p>}
    </div>
  );
}
