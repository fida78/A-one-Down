export default function LegalPage({
  title,
  updated,
  children,
}: {
  title: string;
  updated: string;
  children: React.ReactNode;
}) {
  return (
    <section className="py-20 sm:py-28">
      <div className="container-page max-w-3xl">
        <span className="inline-block text-xs font-mono tracking-widest uppercase text-cyan-signal mb-3">
          Legal
        </span>
        <h1 className="font-display text-3xl sm:text-4xl font-semibold text-white">{title}</h1>
        <p className="mt-3 text-sm text-white/40">Last updated: {updated}</p>
        <div className="progress-divider my-8" />
        <div className="prose-legal flex flex-col gap-8 text-white/65 leading-relaxed">{children}</div>
      </div>
    </section>
  );
}

export function LegalSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="font-display text-xl font-semibold text-white mb-3">{title}</h2>
      <div className="flex flex-col gap-3 text-[15px]">{children}</div>
    </div>
  );
}
