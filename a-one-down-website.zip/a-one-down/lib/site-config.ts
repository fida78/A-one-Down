export const siteConfig = {
  name: "A One Down",
  tagline: "Download Videos Faster with A One Down",
  description:
    "A fast, lightweight, and easy-to-use Android video downloader designed for quick downloads from supported platforms.",
  url: "https://www.aonedown.com",
  apkDownloadUrl: "/downloads/a-one-down.apk",
  supportEmail: "support@yourdomain.com",
  contactEmail: "fidabala78@gmail.com",
  websiteDisplay: "www.yourdomain.com",
  ogImage: "/og-image.png",
  year: 2026,
};

export const navLinks = [
  { label: "Home", href: "/" },
  { label: "Features", href: "/#features" },
  { label: "How to Use", href: "/#how-it-works" },
  { label: "Help Center", href: "/help-center" },
  { label: "Contact", href: "/contact" },
];

export const footerLinks = [
  { label: "Home", href: "/" },
  { label: "Features", href: "/#features" },
  { label: "How to Use", href: "/#how-it-works" },
  { label: "Help Center", href: "/help-center" },
  { label: "Privacy Policy", href: "/privacy-policy" },
  { label: "Terms of Use", href: "/terms-of-use" },
  { label: "Disclaimer", href: "/disclaimer" },
  { label: "Cookie Policy", href: "/cookie-policy" },
  { label: "Contact Us", href: "/contact" },
];
